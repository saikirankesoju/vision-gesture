# Vision-Gesture: Real-Time Adaptive Kinematic Filtering & Hybrid ML-FSM Architecture for Touchless HCI

A low-latency, real-time computer vision hand-gesture mouse controller engineered for B.Tech Final Year Capstone evaluation. Built on **MediaPipe Hand Landmarker**, **2D Isotropic One-Euro Adaptive Filtering** (Casiez et al., CHI 2012), **Hybrid Probabilistic-Deterministic Gesture State Machines**, and **ISO 9241-9 Fitts' Law Quantitative Benchmarking**.

---

## 🌟 Core Engineering & Research Contributions

1. **Hybrid Deterministic-Probabilistic Gesture Architecture**:
   - Combines sub-millisecond geometric kinematics for zero-lag continuous pointing with a **Random Forest probabilistic classifier** (`predict_proba`) that acts as a confidence gate (`ml_confidence_threshold = 0.65`) to accelerate and stabilize mode transitions (`SCROLL`, `STANDBY`).
2. **2D Isotropic One-Euro Filter vs. Kalman & EMA Baselines**:
   - Computes unified Euclidean velocity across $(x, y)$ axes to eliminate directional elliptical lag during diagonal sweeps, paired with a $0.5\text{ px}$ micro-tremor deadband.
   - Includes `Point2DKalmanFilter` (4-state Constant-Velocity model) and `Point2DEMAFilter` baselines in `filters.py` for comparative signal processing evaluation.
3. **Anti Click-Slip Coordinate Stabilization**:
   - Freezes cursor coordinates at pre-pinch onset (`pinch_lock_ratio = 0.105`) to eliminate downward/lateral fingertip deflection during physical thumb-index contact.
4. **Full Mouse Lifecycle & Midas-Touch Mitigation**:
   - **Left Click, Double Click & Drag-and-Drop**: Hysteresis-guarded state machine (`OPEN` $\rightarrow$ `PINCH_CANDIDATE` $\rightarrow$ `PINCHED` $\rightarrow$ `DRAGGING`).
   - **Right Click**: Thumb + Middle pinch with dedicated confirmation window.
   - **Proportional Smooth Scroll**: Sub-tick floating-point velocity accumulator.
   - **Midas-Touch Clutch (`STANDBY`)**: Closed fist pauses tracking so users can rest their hand without unintended cursor displacement.
5. **Strict Two-Hand Role Isolation**:
   - Spatial palm centroid sorting assigns the **Right Hand** exclusively to 1:1 middle-finger cursor control and the **Left Hand** strictly to actions (`scroll`, `click`, `drag`) with a $450\text{ ms}$ dropout grace window.
6. **ISO 9241-9 Fitts' Law Human-Factors Evaluator**:
   - Built-in multi-directional target acquisition benchmark (`fitts_law_evaluator.py`) computing Shannon Index of Difficulty ($ID = \log_2(D/W + 1)$), Movement Time ($MT$), Throughput ($TP$ in $\text{bits/s}$), and Click-Slip displacement across all filter architectures.

---

## 📁 Modular Repository Structure

```text
Vision-Gesture/
├── config.py                  # Cross-platform configuration (zero hardcoded local paths)
├── main.py                    # CLI entry-point (--train, --benchmark, --fitts-law, --filter)
├── controller.py              # High-level multi-hand & hybrid ML-FSM orchestrator
├── gestures/                  # Modularized single-responsibility gesture subpackage
│   ├── __init__.py
│   ├── kinematics.py          # 4-joint middle-finger chain & 3D-invariant palm scaling
│   ├── state_machine.py       # Hybrid ML-FSM, click-slip lock, drag & smooth scroll
│   └── multi_hand.py          # Spatial palm centroid sorting & 2-hand role isolation
├── filters.py                 # 2D Isotropic One-Euro, 2D Kalman Filter, EMA & Ballistics
├── features.py                # Translation, scale, and 2D rotation-invariant normalizer
├── camera.py                  # Threaded webcam capture with OS backend auto-detection
├── detector.py                # Asynchronous MediaPipe HandLandmarker live-stream wrapper
├── cursor.py                  # Coalescing newest-target OS cursor worker thread
├── actions.py                 # Non-blocking FIFO OS mouse/scroll action worker thread
├── overlay.py                 # Zero-allocation glassmorphic HUD & ML confidence badge
├── collect_dataset.py         # Live webcam multi-subject CSV landmark dataset recorder
├── train.py                   # Stratified 5-Fold CV Random Forest training pipeline
├── benchmark_performance.py   # Comparative filter latency, jitter & step-lag study
├── fitts_law_evaluator.py     # ISO 9241-9 Fitts' Law HCI throughput & error evaluator
├── run_all_tests.py           # Automated verification suite (27 unit & integration tests)
├── models/                    # Serialized ML artifacts & MediaPipe task bundle
│   ├── gesture_model.pkl
│   ├── label_encoder.pkl
│   └── hand_landmarker.task
├── data/
│   ├── benchmark_logs/        # Generated ISO 9241-9 Fitts' Law trial CSV logs
│   └── raw_landmarks/         # User-recorded multi-subject gesture CSV datasets
└── tests/                     # Unit and multi-hand concurrency integration tests
    ├── test_filters.py
    ├── test_features.py
    ├── test_controller.py
    └── test_integration.py
```

---

## 🚀 Quick Start & Capstone Defense Commands

### 1. Installation

```bash
pip install -r requirements.txt
```

### 2. Launch Real-Time Controller

```bash
python main.py
# Or compare against Kalman / EMA filters live:
python main.py --filter kalman
python main.py --filter ema
```

### 3. Record Real Multi-Subject Gesture Dataset & Train Classifier

```bash
# Record live webcam landmarks (keys 1-6 for gesture classes) to data/raw_landmarks/
python collect_dataset.py

# Run Stratified 5-Fold Cross-Validation & export models
python main.py --train
```

### 4. Run Quantitative Signal Processing & ISO 9241-9 Fitts' Law Benchmarks

```bash
# Run filter latency, jitter suppression, and step-response lag study:
python benchmark_performance.py

# Run ISO 9241-9 Fitts' Law target acquisition study (exports CSV to data/benchmark_logs/):
python fitts_law_evaluator.py

# Launch interactive OpenCV Fitts' Law target clicking GUI for live user study:
python fitts_law_evaluator.py --interactive
```

### 5. Run Automated Verification Suite (27 Tests)

```bash
python run_all_tests.py
```

---

## 📊 Quantitative Evaluation Summary (For Capstone Report)

### Comparative Signal Processing Study (`benchmark_performance.py`)

| Filter Architecture | Jitter Variance ($\text{px}^2$) | Noise Suppression (%) | 90% Step-Response Lag ($\text{ms}$) |
| :--- | :---: | :---: | :---: |
| **Raw Unfiltered** | $3.3139\text{ px}^2$ | $0.00\%$ | $0.0\text{ ms}$ |
| **EMA Baseline ($\alpha = 0.22$)** | $0.4266\text{ px}^2$ | $87.13\%$ | $300.0\text{ ms}$ |
| **2D Constant-Velocity Kalman** | $0.7372\text{ px}^2$ | $77.75\%$ | $133.3\text{ ms}$ |
| **2D Isotropic One-Euro (Proposed)** | $0.6980\text{ px}^2$ | $78.94\%$ | **$0.0\text{ ms}$** |

### ISO 9241-9 Fitts' Law Target Acquisition Study (`fitts_law_evaluator.py`)

| Controller Condition | Mean Movement Time ($MT$) | Throughput ($TP$) | Mean Click-Slip | Target Miss Rate |
| :--- | :---: | :---: | :---: | :---: |
| **Raw Unfiltered** | $2.462\text{ s}$ | $1.63\text{ bits/s}$ | $13.91\text{ px}$ | $36.7\%$ |
| **EMA Baseline** | $0.945\text{ s}$ | $4.17\text{ bits/s}$ | $1.83\text{ px}$ | $0.0\%$ |
| **2D Kalman Filter** | $1.201\text{ s}$ | $3.28\text{ bits/s}$ | $2.26\text{ px}$ | $0.0\%$ |
| **2D One-Euro + Anchor Lock (Proposed)** | **$0.867\text{ s}$** | **$4.56\text{ bits/s}$** | **$0.00\text{ px}$** | **$0.0\%$** |